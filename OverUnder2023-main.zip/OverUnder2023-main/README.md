# Code repository for C++ and Python: 1258V
![screen gif showing the header of the glitch-in-bio remix being updated to say "hello, world!"](https://thumbs.gfycat.com/KindDistortedIrrawaddydolphin-size_restricted.gif)


## Driving
Files will be uploaded here in python inside `tank.py` and `splitArcade.py`

## Programming
Files will be uploaded here in sample C++ and python formats under `/programming`

Info about PID tuning will be uploaded here in C++ and python under `pidTuning.py` and `pidTuning.cpp`
Skills Autonomous will be uploaded here in C++ under `/skills_auton` in version formats



